package com.RoadReady.DTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReviewResponse {

    private Long id;
    private Long userId; // ID of the user who submitted the review
    private Long carId;  // ID of the car being reviewed
    private int rating;
    private String comment;
    private LocalDateTime reviewDate; // Date when the review was submitted
}
