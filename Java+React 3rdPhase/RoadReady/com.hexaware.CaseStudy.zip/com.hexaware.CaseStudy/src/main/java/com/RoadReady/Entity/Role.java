package com.RoadReady.Entity;

public enum Role {
	    CUSTOMER,
	    ADMIN,
	    RENTAL_AGENT
}
