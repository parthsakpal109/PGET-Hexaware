package com.RoadReady.Controller;

import com.RoadReady.DTO.UserResponse; // Assuming Admin operations might return UserResponse
import com.RoadReady.Service.IUserService; // To manage users as an admin
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private IUserService userService; // Admin functionality often involves user management

    // Endpoint for admin to get all users
    @GetMapping("/users/all")
    public ResponseEntity<List<UserResponse>> getAllUsersForAdmin() {
        List<UserResponse> users = userService.getAllUsers();
        return new ResponseEntity<>(users, HttpStatus.OK);
    }

    // Endpoint for admin to delete a user
    @DeleteMapping("/users/delete/{userId}")
    public ResponseEntity<Void> deleteUserByAdmin(@PathVariable Long userId) {
        try {
            userService.deleteUser(userId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT); // 204 No Content
        } catch (RuntimeException e) {
            // In a real application, distinguish between user not found and other errors
            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // User not found or other error during deletion
        }
    }
    // Future methods for car management, booking oversight, reporting etc. can be added here
    // For example:
    // @GetMapping("/bookings/all")
    // public ResponseEntity<List<BookingResponse>> getAllBookingsForAdmin() { ... }

    // @GetMapping("/payments/all")
    // public ResponseEntity<List<PaymentResponse>> getAllPaymentsForAdmin() { ... }

    // @PostMapping("/cars/add") // If not already handled in CarController
    // public ResponseEntity<CarResponse> addCarByAdmin(@RequestBody CarRequest carRequest) { ... }
}
