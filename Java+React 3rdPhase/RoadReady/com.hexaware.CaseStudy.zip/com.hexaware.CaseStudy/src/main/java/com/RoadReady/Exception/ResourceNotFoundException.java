package com.RoadReady.Exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@SuppressWarnings("serial")
@ResponseStatus(HttpStatus.NOT_FOUND) // This annotation ensures that when this exception is thrown, a 404 Not Found HTTP status is returned.
public class ResourceNotFoundException extends RuntimeException {

    // Default constructor
    public ResourceNotFoundException() {
        super("Resource not found.");
    }

    // Constructor that accepts a custom message
    public ResourceNotFoundException(String message) {
        super(message);
    }

    // Constructor that accepts a message and a cause (another Throwable)
    public ResourceNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
