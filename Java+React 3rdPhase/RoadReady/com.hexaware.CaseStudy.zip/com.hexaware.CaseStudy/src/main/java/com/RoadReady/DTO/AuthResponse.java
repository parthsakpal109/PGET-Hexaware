package com.RoadReady.DTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set; // Import Set
import com.RoadReady.Entity.Role; // Import Role enum

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuthResponse {

    private Long userId;
    private String email;
    private Set<Role> roles; // Changed to Set<Role> for direct representation
}
