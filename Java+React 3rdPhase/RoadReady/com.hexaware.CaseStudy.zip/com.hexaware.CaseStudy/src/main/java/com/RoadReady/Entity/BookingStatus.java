package com.RoadReady.Entity;

public enum BookingStatus {
	PENDING,    // Booking initiated but not yet confirmed (e.g., waiting for payment)
    CONFIRMED,  // Booking successfully confirmed and reserved
    CANCELLED,  // Booking has been cancelled by the user or admin
    COMPLETED   // Booking period has ended and car has been returned
}
