package com.RoadReady.Repository;

import com.RoadReady.Entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

    List<Booking> findByUserId(Long userId);

    List<Booking> findByCarId(Long carId);

    // Custom query to find conflicting bookings for a specific car within a given date range
    // A conflict occurs if an existing booking's period overlaps with the new requested period.
    @Query("SELECT b FROM Booking b WHERE b.car.id = :carId " +
           "AND b.status IN ('CONFIRMED', 'PENDING') " + // Consider only active/pending bookings for conflict
           "AND (" +
           "    (b.pickupDateTime < :dropoffDateTime AND b.dropoffDateTime > :pickupDateTime)" +
           ")")
    List<Booking> findConflictingBookings(@Param("carId") Long carId,
                                          @Param("pickupDateTime") LocalDateTime pickupDateTime,
                                          @Param("dropoffDateTime") LocalDateTime dropoffDateTime);

    // Custom query to find conflicting bookings for a specific car within a given date range,
    // excluding a specific booking (useful for update scenarios where the current booking shouldn't conflict with itself).
    @Query("SELECT b FROM Booking b WHERE b.car.id = :carId " +
           "AND b.id != :excludeBookingId " + // Exclude the current booking being updated
           "AND b.status IN ('CONFIRMED', 'PENDING') " +
           "AND (" +
           "    (b.pickupDateTime < :dropoffDateTime AND b.dropoffDateTime > :pickupDateTime)" +
           ")")
    List<Booking> findConflictingBookingsExcludingCurrent(@Param("carId") Long carId,
                                                          @Param("pickupDateTime") LocalDateTime pickupDateTime,
                                                          @Param("dropoffDateTime") LocalDateTime dropoffDateTime,
                                                          @Param("excludeBookingId") Long excludeBookingId);
}
