package com.RoadReady.Exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data // Lombok annotation for getters, setters, toString, equals, and hashCode
@NoArgsConstructor // Lombok annotation for a no-argument constructor
@AllArgsConstructor // Lombok annotation for a constructor with all fields
public class ErrorDetails {

    private LocalDateTime timestamp; // When the error occurred
    private String message;          // A user-friendly message describing the error
    private String details;          // More specific details, often the request path or internal error info
}
