package com.RoadReady.Entity;

public enum PaymentStatus {
    PENDING,    // Payment initiated but not yet completed
    SUCCESS,    // Payment successfully processed
    FAILED,     // Payment failed
    REFUNDED,   // Payment has been refunded
    CANCELLED   // Payment was cancelled before processing
}
