package com.RoadReady.Service;

import com.RoadReady.DTO.BookingRequest;
import com.RoadReady.DTO.BookingResponse;
import com.RoadReady.Entity.Booking;
import com.RoadReady.Entity.BookingStatus;
import com.RoadReady.Entity.Car;
import com.RoadReady.Entity.User;
import com.RoadReady.Exception.ResourceNotFoundException;
import com.RoadReady.Exception.CarUnavailableException;
import com.RoadReady.Exception.InvalidInputException;
import com.RoadReady.Exception.BookingConflictException;
import com.RoadReady.Repository.BookingRepository;
import com.RoadReady.Repository.CarRepository;
import com.RoadReady.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit; 
import java.util.*;
import java.util.stream.Collectors;

@Service
public class BookingServiceImp implements IBookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CarRepository carRepository;

    @Override
    public BookingResponse makeBooking(BookingRequest bookingRequest, Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with ID: " + userId));

        Car car = carRepository.findById(bookingRequest.getCarId())
                .orElseThrow(() -> new ResourceNotFoundException("Car not found with ID: " + bookingRequest.getCarId()));

        LocalDateTime pickupDateTime = bookingRequest.getPickupDateTime();
        LocalDateTime dropoffDateTime = bookingRequest.getDropoffDateTime();

        if (pickupDateTime.isAfter(dropoffDateTime)) {
            throw new InvalidInputException("Pickup date and time cannot be after dropoff date and time.");
        }
        if (pickupDateTime.isBefore(LocalDateTime.now().minusMinutes(5))) {
            throw new InvalidInputException("Pickup date and time cannot be in the past for a new booking.");
        }
        if (pickupDateTime.isEqual(dropoffDateTime)) {
            throw new InvalidInputException("Pickup and dropoff times cannot be the same. Minimum booking duration is at least one day or part thereof.");
        }

        if (!car.isAvailabilityStatus()) {
            throw new CarUnavailableException("Car with ID " + car.getId() + " is currently marked as unavailable.");
        }

        List<Booking> conflictingBookings = bookingRepository.findConflictingBookings(
                car.getId(),
                pickupDateTime,
                dropoffDateTime
        );

        if (!conflictingBookings.isEmpty()) {
            throw new BookingConflictException("The car is already booked for a portion of the requested time period (" +
                    pickupDateTime.toLocalDate() + " to " + dropoffDateTime.toLocalDate() + ").");
        }

        long days = ChronoUnit.DAYS.between(pickupDateTime.toLocalDate(), dropoffDateTime.toLocalDate()) + 1;
        BigDecimal totalAmount = car.getDailyRate().multiply(BigDecimal.valueOf(days));


        Booking booking = Booking.builder()
                .user(user)
                .car(car)
                .pickupDateTime(pickupDateTime)
                .dropoffDateTime(dropoffDateTime)
                .optionalExtras(bookingRequest.getOptionalExtras())
                .bookingDate(LocalDateTime.now())
                .status(BookingStatus.PENDING) 
                .totalAmount(totalAmount)
                .build();

        Booking savedBooking = bookingRepository.save(booking);

        return convertToBookingResponse(savedBooking);
    }

    @Override
    public BookingResponse updateBooking(Long bookingId, BookingRequest bookingRequest) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with ID: " + bookingId));

        LocalDateTime newPickupDateTime = bookingRequest.getPickupDateTime();
        LocalDateTime newDropoffDateTime = bookingRequest.getDropoffDateTime();

        if (newPickupDateTime.isAfter(newDropoffDateTime)) {
            throw new InvalidInputException("Pickup date and time cannot be after dropoff date and time.");
        }
        if (newPickupDateTime.isEqual(newDropoffDateTime)) {
            throw new InvalidInputException("Pickup and dropoff times cannot be the same. Minimum booking duration is at least one day or part thereof.");
        }
        if (booking.getPickupDateTime().isAfter(LocalDateTime.now()) && newPickupDateTime.isBefore(LocalDateTime.now().minusMinutes(5))) {
             throw new InvalidInputException("Cannot update a future booking's pickup date to a past date.");
        }

        Car newCar = carRepository.findById(bookingRequest.getCarId())
                .orElseThrow(() -> new ResourceNotFoundException("New car not found with ID: " + bookingRequest.getCarId()));

        if (!newCar.isAvailabilityStatus()) {
            throw new CarUnavailableException("New car with ID " + newCar.getId() + " is currently marked as unavailable.");
        }

        List<Booking> conflictingBookings = bookingRepository.findConflictingBookingsExcludingCurrent(
                newCar.getId(),
                newPickupDateTime,
                newDropoffDateTime,
                booking.getId() 
               );

        if (!conflictingBookings.isEmpty()) {
            throw new BookingConflictException("The selected car is not available for the updated time period due to a conflict (" +
                    newPickupDateTime.toLocalDate() + " to " + newDropoffDateTime.toLocalDate() + ").");
        }

        if (!booking.getCar().getId().equals(newCar.getId())) {
            booking.setCar(newCar);
        }

        booking.setPickupDateTime(newPickupDateTime);
        booking.setDropoffDateTime(newDropoffDateTime);
        booking.setOptionalExtras(bookingRequest.getOptionalExtras());

        long days = ChronoUnit.DAYS.between(newPickupDateTime.toLocalDate(), newDropoffDateTime.toLocalDate()) + 1;
        BigDecimal totalAmount = booking.getCar().getDailyRate().multiply(BigDecimal.valueOf(days));
        booking.setTotalAmount(totalAmount);


        Booking updatedBooking = bookingRepository.save(booking);
        return convertToBookingResponse(updatedBooking);
    }

    @Override
    public void cancelBooking(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with ID: " + bookingId));

        if (booking.getStatus() == BookingStatus.CANCELLED) {
            throw new InvalidInputException("Booking with ID " + bookingId + " is already cancelled.");
        }
        if (booking.getStatus() == BookingStatus.COMPLETED) {
            throw new InvalidInputException("Booking with ID " + bookingId + " cannot be cancelled as it is already completed.");
        }

        booking.setStatus(BookingStatus.CANCELLED);
        bookingRepository.save(booking);
        }

    @Override
    public BookingResponse getBookingById(Long bookingId) {
        return bookingRepository.findById(bookingId)
                .map(this::convertToBookingResponse)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with ID: " + bookingId));
    }

    @Override
    public List<BookingResponse> getAllBookings() {
        return bookingRepository.findAll().stream()
                .map(this::convertToBookingResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<BookingResponse> getBookingsByUserId(Long userId) {
        // Ensure the user exists before fetching bookings associated with them
        if (!userRepository.existsById(userId)) {
            throw new ResourceNotFoundException("User not found with ID: " + userId);
        }
        return bookingRepository.findByUserId(userId).stream()
                .map(this::convertToBookingResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<BookingResponse> getBookingsByCarId(Long carId) {
        // Ensure the car exists before fetching bookings associated with it
        if (!carRepository.existsById(carId)) {
            throw new ResourceNotFoundException("Car not found with ID: " + carId);
        }
        return bookingRepository.findByCarId(carId).stream()
                .map(this::convertToBookingResponse)
                .collect(Collectors.toList());
    }
    private BookingResponse convertToBookingResponse(Booking booking) {
        return BookingResponse.builder()
                .id(booking.getId())
                .userId(booking.getUser().getId())
                .carId(booking.getCar().getId())
                .pickupDateTime(booking.getPickupDateTime())
                .dropoffDateTime(booking.getDropoffDateTime())
                .totalAmount(booking.getTotalAmount())
                .status(booking.getStatus())
                .optionalExtras(booking.getOptionalExtras())
                .bookingDate(booking.getBookingDate())
                .build();
    }
}
