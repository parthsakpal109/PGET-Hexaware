create database roadready;

use roadready;

show tables;

desc user_roles;

select * from users;

select * from user_roles;

desc cars;

ALTER TABLE cars MODIFY COLUMN availability_status TINYINT(1) NOT NULL;

update cars set availability_status=1 where id=4;

select * from cars;

desc bookings;

select * from bookings;

desc reviews;

select * from reviews;

desc payments;

select * from payments;